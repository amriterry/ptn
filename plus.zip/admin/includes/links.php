<?php

	echo '
	<!--<link href="http://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css">-->
	<link href="'.$website.'admin/css/default.css" rel="stylesheet" />
	<!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>-->
	<script src="'.$website.'assets/js/jquery.js"></script>
	<script src="'.$website.'admin/js/script.js"></script>
	<script src="'.$website.'admin/js/jPanel.js"></script>
	';

?>