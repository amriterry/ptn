<?php

echo '<div id="footer">
			<center>Admin Panel<br />Copyright © Plus Two Notes 2014<br />From May 27<sup>th</sup> 2014 AD</center>
		</div>';

?>