<?php

require("../includes/conf.inc.php");
require("../includes/functions.inc.php");

if(isset($_POST['query'])){
		
	$query = $_POST['query'];
	$result = mysql_query($query);
	if(!$result){
		$response = array(
			'success' => 0,
			'error' => 1,
			'errorMsg' => mysql_error()
		);
	} else {
		$response = array(
			'success' => 1,
			'error' => 0
		);
	}
	
	echo json_encode($response);
}

?>