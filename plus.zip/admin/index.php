<?php 

require("../includes/conf.inc.php");
require("../includes/functions.inc.php");


if(!isset($_COOKIE['allowAdmin'])){
	if(!isset($_GET['_scob_'])){
		header("location: ../");	
	} else {
		setcookie('allowAdmin','1',0);
		header("location: ../admin/");
	}
} else {
	if(!isset($_SESSION['login'])){
		//$_SESSION['error'] = 2;
		header("location: login.php");	
	} else {
		$adminId = $_SESSION['adminId'];
		$admin = get_admin_info($adminId);
	}
}



?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />	
	<meta name="viewport" content="width=device-width,initial-scale=1" />
	<title>Admin Panel -- Plus Two Notes</title>
	
	<?php require 'includes/links.php'; ?>
</head>
<body>
<!--header-->

<?php require("includes/header.php"); ?>

<div id="notice">
    <h5>Query Status</h5>
    <p></p>
    <br />
    <a href="#" class="anchor-btn" id="ok">Okay</a>
    <br /><br />
    <div class="cleaner"></div>
</div>

<div id="main">

	<?php require("includes/sideBar.php"); ?>

	<div id="rightCol">
		<?php 

		require("includes/dashboard.php");

		if($admin['roleId'] == 1){
			echo '
			<div class="clrscr">
				<h2 class="ico_mug">Query</h2>
				<form action = "query.php" method="post">
					<textarea class="query" name="queryString" cols="100" style="width:100%;margin-bottom:0.5em;" rows="15"></textarea>
					<br />
					<input type="submit" class="btn" value="Query" name="query">
				</form>
			</div>
			';
		}

		require('includes/footer.php');

		?>
	</div>
</div>
</body>
</html>