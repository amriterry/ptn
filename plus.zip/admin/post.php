<?php

if(!isset($_POST['post'])){
	header("Location: index.php");
}
else{
	
	$title = $_POST['title'];
	$chapter = $_POST['chapter'];
	$article = $_POST['article'];
	$author = $_SESSION['adminId'];
	
	$title = mysql_real_escape_string($title);
	$title = trim($title);
	$article = mysql_real_escape_string($article);
	$article = trim($article);
	
	include ("../includes/dbinfo.php");

	$mySqlConn = mysql_connect($host,$username,$password);

	if(!$mySqlConn){
	echo "Error Connecting to MySql: ".mysql_error();
	}
	else{
	//connection to database
	$dbhandle = mysql_select_db($dbname,$mySqlConn);
	
	if(!$dbhandle){
		echo "Error Connecting to Database: ".mysql_error();
	}
	else{
		$query = "INSERT INTO tbl_11physics SET title = '$title',article = '$article',author = '$author',date =NOW(), chapter = '$chapter', tags = '$tags' ";
		
		$result = mysql_query($insertQuery);
	
				if(!$result){
					echo "Posting failed:".mysql_error();
					
				}
				else{
					unset($_POST['post'],$_POST['title'],$_POST['chapter'],$_POST['article']);
					header("Location: index.php?stat=1");
				}
	}
	}
}

?>