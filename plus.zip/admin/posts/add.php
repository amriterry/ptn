<?php

require("../../includes/conf.inc.php");
require("../../includes/functions.inc.php");

if(!isset($_SESSION['login'])){
	$_SESSION['error'] = 2;
	header("location: ../login.php");	
} else {
	$adminId = $_SESSION['adminId'];
	$admin = get_admin_info($adminId);
}

?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />	
	<meta name="viewport" content="width=device-width,initial-scale=1" />
	<title>Plus Two Notes | Add Post</title>
	
	<?php require("../includes/links.php"); ?>

	<link href="../css/uploadfile.css" rel="stylesheet">
	<script src="../js/jquery.uploadfile.js"></script>
	<script src="../js/tinymce/tinymce.min.js"></script>

	<script>
	var minimized = true;
	tinymce.init({
		selector: ".post",
		theme: "modern",
		plugins: "visualblocks,visualchars,code,fullscreen,insertdatetime,nonbreaking,save,table, contextmenu,directionality,emoticons,template,paste,layer,image,advlist,lists,link,charmap,print,preview,hr,anchor,pagebreak,searchreplace,wordcount,media,textcolor,autoresize,spellchecker",
		toolbar1: "undo redo | bold italic superscript subscript | alignleft aligncenter alignright preview | formatselect fontselect forecolor backcolor emoticons",
		toolbar2: "link unlink anchor code | hr removeformat | charmap image media",

		custom_undo_redo_levels: 15,
		image_advtab:true,
		visualblocks_default_state: true,
		force_hex_style_colors: true,
		relative_urls: true,
		content_css: '../css/content_text.css'	
	});

	$(document).ready(function()
	{
		$("#fileuploader").uploadFile({
			url:"uploadImg.php",
			fileName:"file",
			allowedTypes: "jpg,jpeg,png,gif",
			maxFileSize: "1048576",
			uploadButtonClass:"ajax-file-upload-green",
			showStatusAfterSuccess:false,
			showAbort:true,
			showDone:false,
			afterUploadAll:function(){
				$.ajax({
					dataType: 'json',
					url: "getImgList.php",
					success:function(data){
						$("#imgThumbContainer").html('');
						for(i = 0;i < data.length;i++){
							renderImg(data[i]);
						}
					}
				});
			}
		});
	});

	</script>
</head>
<body>

<!--header-->
<?php  require("../includes/header.php"); ?>

<div id="notice">
    <h5>Post Submission Status</h5>
    <p></p>
    <br />
    <a href="#" class="anchor-btn" id="ok">Okay</a>
    <br /><br />
    <div class="cleaner"></div>
</div>

<div id="imgListDialog">
	<span class="right cross"> </span>
	<div class="cleaner"></div>
	<div id="imgThumbContainer"></div>
	<div id="imgOptions">
		<div id="imgDetail">
			<h5>Image Detail</h5>
			<p></p>
		</div>

		<div id="imgUploadContainer">
			<div id="fileuploader">Upload</div>
		</div>
	</div>
</div>

<div id="main">

	<?php require("../includes/sideBar.php"); ?>
		
	<div id="rightCol">
		<?php require("../includes/dashboard.php"); ?>

		<div class="clrscr">
			<h2 class="ico_mug">Add a new Post</h2>
			<form action="post.php" method="post">
				Post Title: <input type="text" name="postTitle" size="100" style="margin-bottom:0.5em;width:100%;"/><br />
				<div class="class select">Class:
					<span id="classSpan">	
					<?php	
						$query = "SELECT * FROM mstclass";
						$result = mysql_query($query,$conn) or die("Error");
						echo '
						<select id="class" name="class">
						<option value="0">-N/A-</option>';
						while($class = mysql_fetch_array($result)){
						echo "
						<option value=".$class['classId'].">".$class['class']."</option>";	
						}
						echo '
						</select>';
					?>
					</span>
				</div> 

				<input type="hidden" name="fileId" value="NULL" id="fileId"/>

				<div class="subject select">Subject: 
					<span id="subSpan">
						<select id="subject" name="subject">
							<option value="0">-N/A-</option>
						</select>
					</span>
				</div>

				<div class="postTyp select">Post Type: 
					<span id="postTypSpan">
						<select id="postTyp" name="postTyp">
							<option value="0">-N/A-</option>
						</select>
					</span>
				</div>				
				<br />

				<span class="anchor-btn" id="imgExp" style="margin-right:1em;">Image Explorer</span>

				<input type="checkbox" name="imp"> Imp
				<br /><br />
				<textarea class="post" style="height:400px;" height="400px" name="textArea" id="postText"></textarea>
				<br />
				<input disabled="disabled" id="submitPost" type="submit" name="post" class="btn" value="Request to Publish"/>
		</form>
		</div>

		<?php require('../includes/footer.php'); ?>

	</div>
</div>
</body>
</html>