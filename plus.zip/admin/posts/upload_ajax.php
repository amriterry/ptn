<?php

session_start();
include("../../../../includes/website.php");
include("../../../../includes/dbinfo.php");
include("../../../../includes/functions.php");
$dbinfo = dbinfo("../../../../includes/dbinfo.txt");
$errorFile = "../../../../includes/error_log.txt";

if(move_uploaded_file($_FILES['file']['tmp_name'],"../../../../uploads/files/".$_FILES['file']['name'])){
	$conn = mysql_connect($dbinfo['host'],$dbinfo['username'],$dbinfo['password']);
	if(!$conn){
		//when not connected
		error_logger($errorFile);
		echo "Error!";
	} else {
		//when connected
		$db_handle = mysql_select_db($dbinfo['name'],$conn);
		if(!$db_handle){
			//when error occurs
			error_logger($errorFile);
			echo "Error!";
		} else {
			$name = $_FILES['file']['name'];
			$url = "uploads/files".$name;
			$size = $_FILES['file']['size'];
			$fileDes = $_POST['fileDes'];
			
			$query = "INSERT INTO file VALUES (NULL,'$name','$url','$size','$fileDes')";
			$result = mysql_query($query,$conn);
			if(!$result){
				echo "Error";
			} else {
				echo "Uploaded";
			}
		}
		mysql_close($conn);
	}
} else {
	echo "Error!";	
}

?>