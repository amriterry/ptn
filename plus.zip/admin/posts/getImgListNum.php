<?php

$path = "../../contents/img/";

?>