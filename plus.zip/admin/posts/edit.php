<?php

require("../../includes/conf.inc.php");
require("../../includes/functions.inc.php");

if(!isset($_SESSION['login'])){
	$_SESSION['error'] = 2;
	header("location: ../login.php");	
} else {
	
	$adminId = $_SESSION['adminId'];
	$admin = get_admin_info($adminId);
	
	if($admin['roleId'] == 1){
		header("location: ../posts/");
	}
	
	if(!isset($_GET['id'])){
		header("location: ../posts/");							 
	} else {
		$id = intval($_GET['id']);
		$post = post::view($id,2);
	
		if($post == 'empty'){
			header("location: ../posts/");
		}
	}
}

?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width,initial-scale=1" />
	<title>Plus Two Notes | Post Editor</title>
	<?php require("../includes/links.php"); ?>
	<script src="../js/tinymce/tinymce.min.js"></script>
	<script>
	tinyMCE.init({
		selector: ".post",
		theme: "modern",
		plugins: "visualblocks,visualchars,code,fullscreen,insertdatetime,nonbreaking,save,table, contextmenu,directionality,emoticons,template,paste,layer,image,advlist,lists,link,charmap,print,preview,hr,anchor,pagebreak,searchreplace,wordcount,media,textcolor,autoresize,spellchecker",
		toolbar1: "undo redo | bold italic superscript subscript | alignleft aligncenter alignright preview | formatselect fontselect forecolor backcolor emoticons",
		toolbar2: "link unlink anchor help code | hr removeformat | charmap image media",

		custom_undo_redo_levels: 15,
		image_advtab:true,
		visualblocks_default_state: true,
		force_hex_style_colors: true,
		relative_urls: true,
		content_css: '../css/content_text.css'
		
	});
	</script>
</head>
<body>

<!--header-->
<?php include("../includes/header.php"); ?>

<div id="notice">
    <h5>Post Update Status</h5>
    <p></p>
    <br />
    <a href="#" class="anchor-btn" id="ok">Okay</a>
    <br /><br />
    <div class="cleaner"></div>
</div>

<div id="imgListDialog">
	<span class="right cross"> </span>
	<div class="cleaner"></div>
	<div id="imgThumbContainer"></div>
	<div id="imgOptions">
		<div id="imgDetail">
			<h5>Image Detail</h5>
			<p></p>
		</div>

		<div id="imgUploadContainer">
			<div id="fileuploader">Upload</div>
		</div>
	</div>
</div>

<div id="main">


<?php include("../includes/sideBar.php"); ?>

<div id="rightCol">

<?php include("../includes/dashboard.php"); ?>

<div class="clrscr">
<h2 class="ico_mug">Post Editor</h2>
<form action="update.php" method="post">
<input type="hidden" name="id" value="<?php echo $id; ?>">
Post Title: <input type="text" name="postTitle" style="width:100%;"size="100" value="<?php echo $post['postTitle']; ?>"/><br /><br />
<p class="postDetail">
<b>Post Type: </b><?php echo $post['postTyp']; ?><br />
<b>Class: </b><?php echo $post['class']; ?><br>
<b>Faculty: </b><?php echo $post['facultyName']; ?><br>
<b>Subject: </b><?php echo $post['subjectName']; ?><br>
<b>Status: </b><span class="postStatus"><?php if($post['statusId'] == 1){ echo "Posted";} else {echo "Pending";} ?></span>
</p>
<span class="anchor-btn" id="imgExp" style="margin-right:1em;">Image Explorer</span>

<input type="checkbox" name="imp" <?php if($post['imp'] == 1){ echo 'checked'; } ?>> Imp
<br /><br />
<textarea class="post" style="height:400px;width:100%;" name="textArea"><?php echo $post['postText']; ?></textarea>
<br />
<input type="submit" id="updatePost" name="update" class="btn" value="Update"/> <?php if($post['statusId'] == 2){ echo '<input type="button" class="btn" value="Publish" id="publishBtn" />'; } ?>
</form>
</div>

	<?php require '../includes/footer.php'; ?>

</div>
</div>
</body>
</html>