<?php

require("../../includes/conf.inc.php");
require("../../includes/functions.inc.php");

$subject = $_POST['selSubId'];

$query = "SELECT * FROM mstchapter
JOIN mstsubject ON mstsubject.subjectId = mstchapter.subjectId
WHERE mstsubject.subjectId = '$subject'";

$result = mysql_query($query,$conn) or die("0");

$response = '<option value="0">-N/A-</option>';

while($chapter = mysql_fetch_array($result)){
	$response =  $response."
	<option value=".$chapter['chapterId'].">".$chapter['chapterName']."</option>";
}

echo $response;

?>