<?php

include("includes/conf.inc.php");
include("includes/functions.inc.php");

$query = "SELECT postId,posts.chapterId,mstchapter.subjectId
FROM posts
JOIN mstchapter ON mstchapter.chapterId = posts.chapterId
JOIN mstsubject ON mstsubject.subjectId = mstchapter.subjectId";

$result = mysql_query($query);
if(!$result){
	die(mysql_error());
}

$numPosts = mysql_num_rows($result);

$insertQuery = "";
$i = 1;
while($post = mysql_fetch_array($result)){
	$chapterId = $post['chapterId'];
	$subjectId = $post['subjectId'];
	$insertQuery[$i-1] = "UPDATE `posts` SET `chapterId` = '$subjectId' WHERE `chapterId` = '$chapterId'";
	$i++;
}

echo 'Update Table Rows Query: <br /><textarea cols=50 rows=20>';
foreach($insertQuery as $q){
	echo $q.'   ';
}

echo '</textarea><br /><br />';

$alter = "ALTER TABLE posts CHANGE chapterId subjectId INT";

echo 'Update Table Column Name Query: <br /><textarea cols=50 rows=20>'.$alter.'</textarea><br /><br />';

$movePostsrQ = "SELECT * FROM postsr";

$mvResult = mysql_query($movePostsrQ);

if(!$mvResult){
	die(mysql_error());
}

$insQ = "INSERT INTO posts VALUES ";

$mvRnum = mysql_num_rows($mvResult);

$j = 1;
while($postsr = mysql_fetch_array($mvResult)){
	$postTitle = mysql_real_escape_string($postsr['postTitle']));
	$postText = mysql_real_escape_string($postsr['postText']));
	$postDate = $postsr['postDate'];
	$subjectId = $postsr['subjectId'];
	$postTypId = $postsr['postTypId'];
	$fileId = $postsr['fileId'];
	$adminId = $postsr['adminId'];
	$statusId = $postsr['statusId'];
	$imp = $postsr['imp'];
	$likeCount = $postsr['likeCount'];
	$insQ .= "(NULL,'$postTitle','$postText','$postDate','$subjectId','$postTypId','$fileId','$adminId','$statusId','$imp','$likeCount')";

		if($j != $mvRnum){
			$insQ .=", ";
		}
	$j++;
}

echo 'Update Table Merge Query: <br /><textarea cols=50 rows=20>'.$insQ.'</textarea><br /><br />';

foreach ($insertQuery as $q) {
	$updTbl = mysql_query($q);
	if(!$updTbl){
		die(mysql_error());
	} else {
		echo 'Updated Table...<br />';
	}
}

$alterRes = mysql_query($alter);
if(!$alterRes){
	die(mysql_error());
} else {
	echo 'Altered Table Column Name<br />';
}

$insR = mysql_query($insQ);
if(!$insR){
	die(mysql_error());
} else {
	echo 'Inserted Data into Table<br />';
}
?>