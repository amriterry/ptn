<?php 

echo '
<footer id="footer">
	Copyright © Plus Two Notes<br />2014<br />All Rights Reserved
</footer><!--end of #footer -->';

?>