<?php

echo '
<div id="main-nav">
	<a href="javascript:;" class="menu-link"></a>
	<div class="cleaner"></div>
	<div class="wrapper">
		<nav id="nav">
			<ul class="menu">
				<li><a href="'.$website.'">Home</a></li>
				<li><a href="#">Syllabus</a>
					<ul>
						<li><a href="#">Grade 11</a>
								<ul>
									<li><a href="#">Science</a>
										<ul>
											<li><a href="'.$website.'syllabus/physics/1">Physics</a></li>
											<li><a href="'.$website.'syllabus/chemistry/2">Chemistry</a></li>
											<li><a href="'.$website.'syllabus/biology/3">Biology</a></li>
											<li><a href="'.$website.'syllabus/maths/4">Maths</a></li>
											<li><a href="'.$website.'syllabus/computer-science/6">Computer Science</a></li>
											<li><a href="'.$website.'syllabus/english/5">English</a></li>
										</ul>
									</li>
									<li><a href="#">Management</a>
										<ul>
											<li><a href="'.$website.'syllabus/business-maths/12">Business Maths</a></li>
											<li><a href="'.$website.'syllabus/economics/13">Economics</a></li>
											<li><a href="'.$website.'syllabus/accountancy/14">Accountancy</a></li>
											<li><a href="'.$website.'syllabus/computer-science/15">Computer Science</a></li>
											<li><a href="'.$website.'syllabus/english/16">English</a></li>
										</ul>
									</li>
								</ul>
							</li>
							<li><a href="#">Grade 12</a>
								<ul>
									<li><a href="#">Science</a>
										<ul>
											<li><a href="'.$website.'syllabus/physics/7">Physics</a></li>
											<li><a href="'.$website.'syllabus/chemistry/8">Chemistry</a></li>
											<li><a href="'.$website.'syllabus/biology/9">Biology</a></li>
											<li><a href="'.$website.'syllabus/maths/10">Maths</a></li>
											<li><a href="'.$website.'syllabus/english/11">English</a></li>
										</ul>
									</li>
									<li><a href="#">Management</a>
										<ul>
											<li><a href="'.$website.'syllabus/business-maths/17">Business Maths</a></li>
											<li><a href="'.$website.'syllabus/economics/18">Economics</a></li>
											<li><a href="'.$website.'syllabus/computer-science/19">Computer Science</a></li>
											<li><a href="'.$website.'syllabus/english/20">English</a></li>
										</ul>
									</li>
								</ul>
							</li>
					</ul>
				</li>
				<li><a href="#">Refrence Books</a>
					<ul>
						<li><a href="#">Grade 11</a>
								<ul>
									<li><a href="#">Science</a>
										<ul>
											<li><a href="'.$website.'refrence/physics/1">Physics</a></li>
											<li><a href="'.$website.'refrence/chemistry/2">Chemistry</a></li>
											<li><a href="'.$website.'refrence/biology/3">Biology</a></li>
											<li><a href="'.$website.'refrence/maths/4">Maths</a></li>
											<li><a href="'.$website.'refrence/computer-science/6">Computer Science</a></li>
											<li><a href="'.$website.'refrence/english/5">English</a></li>
										</ul>
									</li>
									<li><a href="#">Management</a>
										<ul>
											<li><a href="'.$website.'refrence/business-maths/12">Business Maths</a></li>
											<li><a href="'.$website.'refrence/economics/13">Economics</a></li>
											<li><a href="'.$website.'refrence/accountancy/14">Accountancy</a></li>
											<li><a href="'.$website.'refrence/computer-science/15">Computer Science</a></li>
											<li><a href="'.$website.'refrence/english/16">English</a></li>
										</ul>
									</li>
								</ul>
							</li>
							<li><a href="#">Grade 12</a>
								<ul>
									<li><a href="#">Science</a>
										<ul>
											<li><a href="'.$website.'refrence/physics/7">Physics</a></li>
											<li><a href="'.$website.'refrence/chemistry/8">Chemistry</a></li>
											<li><a href="'.$website.'refrence/biology/9">Biology</a></li>
											<li><a href="'.$website.'refrence/maths/10">Maths</a></li>
											<li><a href="'.$website.'refrence/english/11">English</a></li>
										</ul>
									</li>
									<li><a href="#">Management</a>
										<ul>
											<li><a href="'.$website.'refrence/business-maths/17">Business Maths</a></li>
											<li><a href="'.$website.'refrence/economics/18">Economics</a></li>
											<li><a href="'.$website.'refrence/computer-science/19">Computer Science</a></li>
											<li><a href="'.$website.'refrence/english/20">English</a></li>
										</ul>
									</li>
								</ul>
							</li>
					</ul>
				</li>
				<li><a href="#">Notes</a>
					<ul>
						<li><a href="#">Grade 11</a>
								<ul>
									<li><a href="#">Science</a>
										<ul>
											<li><a href="'.$website.'notes/physics/1">Physics</a></li>
											<li><a href="'.$website.'notes/chemistry/2">Chemistry</a></li>
											<li><a href="'.$website.'notes/biology/3">Biology</a></li>
											<li><a href="'.$website.'notes/maths/4">Maths</a></li>
											<li><a href="'.$website.'notes/computer-science/6">Computer Science</a></li>
											<li><a href="'.$website.'notes/english/5">English</a></li>
										</ul>
									</li>
									<li><a href="#">Management</a>
										<ul>
											<li><a href="'.$website.'notes/business-maths/12">Business Maths</a></li>
											<li><a href="'.$website.'notes/economics/13">Economics</a></li>
											<li><a href="'.$website.'notes/accountancy/14">Accountancy</a></li>
											<li><a href="'.$website.'notes/computer-science/15">Computer Science</a></li>
											<li><a href="'.$website.'notes/english/16">English</a></li>
										</ul>
									</li>
								</ul>
							</li>
							<li><a href="#">Grade 12</a>
								<ul>
									<li><a href="#">Science</a>
										<ul>
											<li><a href="'.$website.'notes/physics/7">Physics</a></li>
											<li><a href="'.$website.'notes/chemistry/8">Chemistry</a></li>
											<li><a href="'.$website.'notes/biology/9">Biology</a></li>
											<li><a href="'.$website.'notes/maths/10">Maths</a></li>
											<li><a href="'.$website.'notes/english/11">English</a></li>
										</ul>
									</li>
									<li><a href="#">Management</a>
										<ul>
											<li><a href="'.$website.'notes/business-maths/17">Business Maths</a></li>
											<li><a href="'.$website.'notes/economics/18">Economics</a></li>
											<li><a href="'.$website.'notes/computer-science/19">Computer Science</a></li>
											<li><a href="'.$website.'notes/english/20">English</a></li>
										</ul>
									</li>
								</ul>
							</li>
					</ul>
				</li>
				<li><a href="#">Questions </a>
					<ul>
						<li><a href="#">Grade 11</a>
								<ul>
									<li><a href="#">Science</a>
										<ul>
											<li><a href="'.$website.'questions/physics/1">Physics</a></li>
											<li><a href="'.$website.'questions/chemistry/2">Chemistry</a></li>
											<li><a href="'.$website.'questions/biology/3">Biology</a></li>
											<li><a href="'.$website.'questions/maths/4">Maths</a></li>
											<li><a href="'.$website.'questions/computer-science/6">Computer Science</a></li>
											<li><a href="'.$website.'questions/english/5">English</a></li>
										</ul>
									</li>
									<li><a href="#">Management</a>
										<ul>
											<li><a href="'.$website.'questions/business-maths/12">Business Maths</a></li>
											<li><a href="'.$website.'questions/economics/13">Economics</a></li>
											<li><a href="'.$website.'questions/accountancy/14">Accountancy</a></li>
											<li><a href="'.$website.'questions/computer-science/15">Computer Science</a></li>
											<li><a href="'.$website.'questions/english/16">English</a></li>
										</ul>
									</li>
								</ul>
							</li>
							<li><a href="#">Grade 12</a>
								<ul>
									<li><a href="#">Science</a>
										<ul>
											<li><a href="'.$website.'questions/physics/7">Physics</a></li>
											<li><a href="'.$website.'questions/chemistry/8">Chemistry</a></li>
											<li><a href="'.$website.'questions/biology/9">Biology</a></li>
											<li><a href="'.$website.'questions/maths/10">Maths</a></li>
											<li><a href="'.$website.'questions/english/11">English</a></li>
										</ul>
									</li>
									<li><a href="#">Management</a>
										<ul>
											<li><a href="'.$website.'questions/business-maths/17">Business Maths</a></li>
											<li><a href="'.$website.'questions/economics/18">Economics</a></li>
											<li><a href="'.$website.'questions/computer-science/19">Computer Science</a></li>
											<li><a href="'.$website.'questions/english/20">English</a></li>
										</ul>
									</li>
								</ul>
							</li>
					</ul>
				</li>
				<!--<li><a href="#">Downloads</a></li>-->
				<li><a href="'.$website.'about/">About Us</a></li>
				<li><a href="'.$website.'contact/">Contact Us</a></li>
			</ul>
			<div class="cleaner"></div>
		</nav>
	</div>
</div>';

?>