<?php

echo '
<!--<link href="http://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css">-->
<link href="'.$website.'assets/css/default.css" rel="stylesheet" />
<link href="'.$website.'favicon.ico" rel="shortcut icon" />
<link href="'.$website.'favicon.ico" rel="icon" />
<!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>-->
<script src="'.$website.'assets/js/jquery.js"></script>
<script src="'.$website.'assets/js/plugins.min.js"></script>
<script src="'.$website.'assets/js/script.js"></script>';

?>