<?php

echo '

	<h1 class="welcome-heading">Welcome to <span>Plus Two Notes</span></h1>
	<center><img src="assets/img/logo.jpg" alt="Plus Two Notes - a site for complete Plus Two HSEB based Notes and Other Educational Materials."/></center>
	<p class="highlighted">
	<b>Representing class confabs Online!</b> We provide you with rich, easy and comprehensive notes based on HSEB Plus Two Syllabus. Also we have other educational materials like HSEB syllabus. We also make selection of books easier. We have a Refrence Book section in our site to help you to chose best books available in your local market which are benificial for your Plus Two Level Education. You can also read our Question Answer Section where we have posted important questions along with their answers as per HSEB syllaubs, inclusive of "Old is Gold". We will further improve this site based on your suggestions so that you can <em>Experience your School at your home</em>
	</p>
	<br /><br />
	<center>
			<div style="position:relative;top:-3px;" class="fb-share-button" data-href="http://www.plustwonotes.com" data-type="box_count"></div>
			
			<div class="g-plusone" data-size="tall"></div>

			<!-- Place this tag after the last +1 button tag. -->';

			echo "
			<script type=\"text/javascript\">
			  (function() {
			    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
			    po.src = 'https://apis.google.com/js/platform.js';
			    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
			  })();
			</script>

	</center>";

?>